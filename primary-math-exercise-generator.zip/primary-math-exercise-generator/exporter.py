# -*- coding: utf-8 -*-
"""
小学生数学练习题目自动生成系统 —— 导出模块
============================================
支持导出为 TXT 纯文本和 DOCX Word 文档两种格式。
"""

import os
import datetime
from typing import List, Dict


class Exporter:
    """
    题目导出器。

    将生成好的题目列表导出为 TXT 或 DOCX 文件。
    """

    def __init__(self, questions: List[dict], grade_name: str = "练习卷"):
        """
        Args:
            questions:  题目列表（来自 generator.py 的输出）
            grade_name: 年级名称，用于标题
        """
        self.questions = questions
        self.grade_name = grade_name
        self.timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # ============================================================
    # TXT 导出
    # ============================================================

    def export_txt(self, output_dir: str, filename_prefix: str = "exercise") -> str:
        """
        导出为 TXT 纯文本文件。

        生成两个文件：
          - {prefix}_题目.txt   仅包含题目
          - {prefix}_答案.txt   题目 + 答案对照

        Args:
            output_dir:      输出目录
            filename_prefix: 文件名前缀

        Returns:
            (题目文件路径, 答案文件路径) 元组
        """
        os.makedirs(output_dir, exist_ok=True)

        questions_path = os.path.join(output_dir, f"{filename_prefix}_题目.txt")
        answers_path = os.path.join(output_dir, f"{filename_prefix}_答案.txt")

        # ---- 题目文件 ----
        with open(questions_path, "w", encoding="utf-8") as f:
            f.write(f"{'=' * 50}\n")
            f.write(f"   {self.grade_name} 数学练习题\n")
            f.write(f"   生成时间: {self.timestamp}\n")
            f.write(f"   题目总数: {len(self.questions)} 道\n")
            f.write(f"{'=' * 50}\n\n")

            f.write("【题目】\n")
            f.write("-" * 50 + "\n\n")

            for q in self.questions:
                f.write(f"{q['id']}. {q['topic']} = ____\n")
                f.write("\n")

            f.write("-" * 50 + "\n")
            f.write("做完再对答案哦！\n")

        # ---- 答案文件 ----
        with open(answers_path, "w", encoding="utf-8") as f:
            f.write(f"{'=' * 50}\n")
            f.write(f"   {self.grade_name} 数学练习题 — 答案\n")
            f.write(f"   生成时间: {self.timestamp}\n")
            f.write(f"{'=' * 50}\n\n")

            f.write("【题目与答案对照】\n")
            f.write("-" * 50 + "\n\n")

            for q in self.questions:
                f.write(f"{q['id']}. {q['topic']} = {q['answer']}\n")
                f.write("\n")

            f.write("-" * 50 + "\n")
            f.write("学习加油！\n")

        return questions_path, answers_path

    # ============================================================
    # DOCX 导出
    # ============================================================

    def export_docx(self, output_dir: str, filename: str = "exercise.docx") -> str:
        """
        导出为 DOCX Word 文档（试卷排版，适合直接打印）。

        文档结构：
          - 标题 + 基本信息
          - 题目区（每题占一行，末尾留横线填空）
          - 分页
          - 答案区

        Args:
            output_dir: 输出目录
            filename:   文件名

        Returns:
            生成的 DOCX 文件路径
        """
        try:
            from docx import Document
            from docx.shared import Pt, Cm, Inches
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            from docx.oxml.ns import qn
        except ImportError:
            raise ImportError("请先安装 python-docx: pip install python-docx")

        os.makedirs(output_dir, exist_ok=True)
        filepath = os.path.join(output_dir, filename)

        doc = Document()

        # ---- 页面设置 ----
        section = doc.sections[0]
        section.page_width = Cm(21)     # A4
        section.page_height = Cm(29.7)
        section.top_margin = Cm(2)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)

        # ---- 标题 ----
        title_para = doc.add_paragraph()
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_run = title_para.add_run(f"{self.grade_name} 数学练习题")
        title_run.bold = True
        title_run.font.size = Pt(22)
        title_run.font.name = "黑体"
        self._set_east_asian_font(title_run, "黑体")

        # ---- 基本信息 ----
        info_para = doc.add_paragraph()
        info_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        info_run = info_para.add_run(
            f"姓名：________    日期：________    得分：________"
        )
        info_run.font.size = Pt(12)
        info_run.font.name = "宋体"
        self._set_east_asian_font(info_run, "宋体")

        # 分隔线
        doc.add_paragraph("─" * 50)

        # ---- 题目区 ----
        question_header = doc.add_paragraph()
        qh_run = question_header.add_run("一、计算题（把答案写在横线上）")
        qh_run.bold = True
        qh_run.font.size = Pt(14)
        qh_run.font.name = "宋体"
        self._set_east_asian_font(qh_run, "宋体")

        for q in self.questions:
            para = doc.add_paragraph()
            # 题号 + 题目 + 横线
            text = f"{q['id']}.    {q['topic']} = ________"
            run = para.add_run(text)
            run.font.size = Pt(14)
            run.font.name = "宋体"
            self._set_east_asian_font(run, "宋体")
            # 行间距
            para.paragraph_format.space_after = Pt(8)
            para.paragraph_format.line_spacing = 1.5

        # ---- 分页，答案区 ----
        doc.add_page_break()

        answer_header = doc.add_paragraph()
        ah_run = answer_header.add_run("参考答案")
        ah_run.bold = True
        ah_run.font.size = Pt(18)
        ah_run.font.name = "黑体"
        self._set_east_asian_font(ah_run, "黑体")
        answer_header.alignment = WD_ALIGN_PARAGRAPH.CENTER

        doc.add_paragraph()

        for q in self.questions:
            para = doc.add_paragraph()
            text = f"{q['id']}.    {q['topic']} = {q['answer']}"
            run = para.add_run(text)
            run.font.size = Pt(12)
            run.font.name = "宋体"
            self._set_east_asian_font(run, "宋体")
            para.paragraph_format.space_after = Pt(4)

        # ---- 保存 ----
        doc.save(filepath)
        return filepath

    @staticmethod
    def _set_east_asian_font(run, font_name: str):
        """设置中文字体（西文和东亚字体分别设置）"""
        from docx.oxml.ns import qn
        run.font.name = font_name
        r = run._element
        rPr = r.find(qn('w:rPr'))
        if rPr is None:
            rPr = r.makeelement(qn('w:rPr'), {})
            r.insert(0, rPr)
        rFonts = rPr.find(qn('w:rFonts'))
        if rFonts is None:
            rFonts = rPr.makeelement(qn('w:rFonts'), {})
            rPr.insert(0, rFonts)
        rFonts.set(qn('w:eastAsia'), font_name)


def export_all(questions: List[dict], grade_name: str, output_dir: str,
               prefix: str = "exercise"):
    """
    一键导出 TXT 和 DOCX 两种格式。

    Args:
        questions:  题目列表
        grade_name: 年级名称
        output_dir: 输出目录
        prefix:     文件名前缀

    Returns:
        dict: {"txt_questions": path, "txt_answers": path, "docx": path}
    """
    exporter = Exporter(questions, grade_name)
    q_path, a_path = exporter.export_txt(output_dir, prefix)
    d_path = exporter.export_docx(output_dir, f"{prefix}.docx")
    return {
        "txt_questions": q_path,
        "txt_answers": a_path,
        "docx": d_path,
    }
