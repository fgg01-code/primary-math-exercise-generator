# -*- coding: utf-8 -*-
"""
小学生数学练习题目自动生成系统 —— 题目生成核心模块
====================================================
支持加减乘除、四则混合运算（带/不带括号）、简单应用题等多种题型。
"""

import random
import math
from typing import List, Tuple, Optional
from config import GradeConfig


class ExerciseGenerator:
    """
    数学题目生成器。

    根据传入的 GradeConfig 配置，生成指定数量、指定题型的练习题。
    """

    def __init__(self, config: GradeConfig, seed: Optional[int] = None):
        """
        初始化生成器。

        Args:
            config: 年级/难度配置
            seed:   随机种子（用于复现同一套题）
        """
        self.cfg = config
        if seed is not None:
            random.seed(seed)

    # ============================================================
    # 公共入口
    # ============================================================

    def generate(self, total_count: int) -> List[dict]:
        """
        生成 total_count 道题目，题型按启用的开关均匀分配。

        Args:
            total_count: 题目总数

        Returns:
            题目列表，每道题为 dict:
            {
                "id": int,              # 题号 (1-based)
                "topic": str,           # 题目文字（含运算符）
                "answer": str,          # 标准答案
                "question_line": str,   # 带题号的展示行（如 "1. 3 + 5 = ____"）
                "type": str,            # 题型标签
            }
        """
        # 收集已启用的题型生成函数
        available_types = self._get_available_types()
        if not available_types:
            raise ValueError("未启用任何题型，请检查 GradeConfig 配置")

        questions: List[dict] = []

        for i in range(total_count):
            # 轮转选择题型
            gen_func = available_types[i % len(available_types)]
            question = gen_func()
            question["id"] = i + 1
            question["question_line"] = f"{i + 1}. {question['topic']} = ____"
            questions.append(question)

        return questions

    # ============================================================
    # 题型生成器（内部）
    # ============================================================

    def _get_available_types(self) -> list:
        """收集所有启用的题型生成函数"""
        types = []
        if self.cfg.enable_addition:
            types.append(self._gen_addition)
        if self.cfg.enable_subtraction:
            types.append(self._gen_subtraction)
        if self.cfg.enable_multiplication:
            types.append(self._gen_multiplication)
        if self.cfg.enable_division:
            types.append(self._gen_division)
        if self.cfg.enable_mixed:
            types.append(self._gen_mixed)
        if self.cfg.enable_word_problems:
            types.append(self._gen_word_problem)
        return types

    # ---- 数值生成工具 ----

    def _rand_int(self, lo: int = None, hi: int = None) -> int:
        """生成 [lo, hi] 范围内的随机整数"""
        lo = lo if lo is not None else self.cfg.min_num
        hi = hi if hi is not None else self.cfg.max_num
        return random.randint(lo, hi)

    def _rand_decimal(self, lo: int = None, hi: int = None) -> float:
        """生成带小数的随机数"""
        lo = lo if lo is not None else self.cfg.min_num
        hi = hi if hi is not None else self.cfg.max_num
        value = random.randint(int(lo * 10**self.cfg.decimal_places),
                               int(hi * 10**self.cfg.decimal_places))
        return value / (10 ** self.cfg.decimal_places)

    def _format_num(self, n) -> str:
        """格式化数值：整数直接显示，小数保留指定位数"""
        if isinstance(n, int) or (isinstance(n, float) and n == int(n)):
            return str(int(n))
        return f"{n:.{self.cfg.decimal_places}f}".rstrip('0').rstrip('.')

    def _gen_num(self) -> float:
        """根据 decimal_places 决定生成整数或小数"""
        if self.cfg.decimal_places == 0:
            return self._rand_int()
        return self._rand_decimal()

    # ---- 1. 加法 ----

    def _gen_addition(self) -> dict:
        """生成一道加法题"""
        a = self._gen_num()
        b = self._gen_num()
        if self.cfg.allow_carry:
            # 进位加法：确保个位相加 >= 10
            if self.cfg.decimal_places == 0:
                a_ones = a % 10
                b_ones = b % 10
                if a_ones + b_ones < 10:
                    b += (10 - a_ones - b_ones)
            a, b = sorted([a, b], reverse=True)  # 大数在前
        answer = a + b
        return {
            "topic": f"{self._format_num(a)} + {self._format_num(b)}",
            "answer": self._format_num(answer),
            "type": "加法",
            "expression": f"{a} + {b}",
        }

    # ---- 2. 减法 ----

    def _gen_subtraction(self) -> dict:
        """生成一道减法题"""
        a = self._gen_num()
        b = self._gen_num()
        a, b = max(a, b), min(a, b)  # 确保非负结果
        if a == b:
            a += 1  # 避免结果为 0
        if self.cfg.allow_borrow and self.cfg.decimal_places == 0:
            # 退位减法：确保个位不够减
            a_ones = a % 10
            b_ones = b % 10
            if a_ones >= b_ones:
                if a_ones >= 9:
                    # a 个位为 9 时，直接整体调整 b
                    b = a - random.randint(1, min(9, a))
                else:
                    new_b_ones = a_ones + random.randint(1, 9 - a_ones)
                    b = (b // 10) * 10 + new_b_ones
                    if b >= a:
                        b = a - random.randint(1, min(9, a))
        answer = a - b
        return {
            "topic": f"{self._format_num(a)} - {self._format_num(b)}",
            "answer": self._format_num(answer),
            "type": "减法",
            "expression": f"{a} - {b}",
        }

    # ---- 3. 乘法 ----

    def _gen_multiplication(self) -> dict:
        """生成一道乘法题（基于乘法口诀表范围）"""
        a = random.randint(1, self.cfg.multiplication_table_max)
        b = random.randint(1, self.cfg.multiplication_table_max)
        answer = a * b
        return {
            "topic": f"{self._format_num(a)} × {self._format_num(b)}",
            "answer": self._format_num(answer),
            "type": "乘法",
            "expression": f"{a} * {b}",
        }

    # ---- 4. 除法 ----

    def _gen_division(self) -> dict:
        """生成一道除法题"""
        divisor = random.randint(2, self.cfg.division_divisor_max)
        quotient = random.randint(1, self.cfg.multiplication_table_max)
        dividend = divisor * quotient

        if self.cfg.allow_remainder:
            # 带余数除法
            remainder = random.randint(1, divisor - 1)
            dividend += remainder
            answer = f"{quotient} 余 {remainder}"
            expression = f"{dividend} // {divisor} (商{quotient}, 余{remainder})"
        else:
            answer = str(quotient)
            expression = f"{dividend} / {divisor}"

        return {
            "topic": f"{dividend} ÷ {divisor}",
            "answer": answer,
            "type": "除法",
            "expression": expression,
        }

    # ---- 5. 四则混合运算 ----

    def _gen_mixed(self) -> dict:
        """生成一道四则混合运算题（含或不含括号）"""
        ops = []
        if self.cfg.enable_addition:
            ops.append("+")
        if self.cfg.enable_subtraction:
            ops.append("-")
        if self.cfg.enable_multiplication:
            ops.append("×")
        if self.cfg.enable_division:
            ops.append("÷")

        if len(ops) < 2:
            # 运算符不足，降级为纯加法
            return self._gen_addition()

        n = self.cfg.mixed_operators_count  # 运算符个数
        # 生成操作数
        numbers = []
        for _ in range(n + 1):
            # 乘除法参与时限制数值不要太大
            hi = min(self.cfg.max_num, 100)
            numbers.append(random.randint(1, hi))

        # 生成运算符序列
        op_seq = [random.choice(ops) for _ in range(n)]

        # 构造表达式字符串及展示式
        expr_parts = [str(numbers[0])]
        eval_expr = [str(numbers[0])]
        for i, op in enumerate(op_seq):
            expr_parts.append(op)
            expr_parts.append(str(numbers[i + 1]))
            # 用于 eval 计算
            py_op = op.replace("×", "*").replace("÷", "/")
            eval_expr.append(py_op)
            eval_expr.append(str(numbers[i + 1]))

        # 是否加括号
        has_parentheses = False
        if self.cfg.allow_parentheses and n >= 2:
            # 对前 paren_end 个操作数加括号
            paren_start = 0
            paren_end = random.randint(1, min(2, n))
            if paren_end > paren_start:
                has_parentheses = True
                # 操作数在偶数索引 0,2,4,...; ) 插入到第 paren_end 个操作数后面
                # 原始目标索引 = 2*paren_end - 1，因 '(' 插入后偏移 +1，故最终 = 2*paren_end
                left_pos = paren_start * 2
                right_pos = paren_end * 2
                expr_parts.insert(left_pos, "(")
                expr_parts.insert(right_pos, ")")
                eval_expr.insert(left_pos, "(")
                eval_expr.insert(right_pos, ")")

        raw_topic = " ".join(expr_parts)
        raw_expression = " ".join(eval_expr)

        # 计算答案
        try:
            answer = eval(raw_expression)
            # 判断是否为整数结果
            if answer == int(answer):
                answer = int(answer)
                answer_str = str(answer)
            else:
                # 保留最多 4 位小数，去除尾部多余的 0
                answer_str = f"{answer:.4f}".rstrip('0').rstrip('.')
        except ZeroDivisionError:
            # 除法出现除数为 0，重新生成
            return self._gen_mixed()

        # 确保结果非负
        if answer < 0:
            return self._gen_mixed()

        return {
            "topic": raw_topic,
            "answer": answer_str,
            "type": "四则混合",
            "expression": raw_expression,
        }

    # ---- 6. 简单应用题 ----

    def _gen_word_problem(self) -> dict:
        """生成一道简单应用题"""
        templates = self.cfg.word_problem_templates
        template = random.choice(templates)

        # 为模板生成合理数值
        if "吃了" in template or "飞走" in template or "给了" in template:
            # 减少型应用题
            a = random.randint(5, self.cfg.max_num)
            b = random.randint(1, a)
            answer = a - b
            topic = template.format(a=a, b=b)
            op_type = "减法应用题"
        elif "飞来" in template or "又来" in template:
            # 增加型应用题
            a = random.randint(1, self.cfg.max_num // 2)
            b = random.randint(1, self.cfg.max_num // 2)
            answer = a + b
            topic = template.format(a=a, b=b)
            op_type = "加法应用题"
        else:
            # 通用（乘法类等）
            a = random.randint(1, 10)
            b = random.randint(1, 10)
            answer = a * b
            topic = template.format(a=a, b=b)
            op_type = "乘法应用题"

        return {
            "topic": topic,
            "answer": str(answer) if answer == int(answer) else f"{answer:.1f}",
            "type": op_type,
            "expression": topic,
        }


# ============================================================
# 便捷函数
# ============================================================

def generate_exercises(grade: int = 1, total_count: int = 20, seed: Optional[int] = None) -> List[dict]:
    """
    快捷生成函数：按年级预设配置生成题目。

    Args:
        grade:       年级 (1-6)
        total_count: 题目总数
        seed:        随机种子

    Returns:
        题目列表

    Example:
        >>> questions = generate_exercises(grade=3, total_count=30)
    """
    from config import get_grade_config
    cfg = get_grade_config(grade)
    gen = ExerciseGenerator(cfg, seed=seed)
    return gen.generate(total_count)
