# -*- coding: utf-8 -*-
"""
小学生数学练习题目自动生成系统 —— 程序入口
============================================
一键生成指定年级、指定数量的数学练习卷。
支持导出 TXT（题目+答案分开）和 DOCX（Word 试卷排版）。
"""

import os
import sys
import argparse
from config import get_grade_config, PRESET_GRADES
from generator import ExerciseGenerator
from answer_calc import batch_calc, verify_answers
from exporter import export_all


def main():
    parser = argparse.ArgumentParser(
        description="小学生数学练习题目自动生成系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  python main.py                          # 默认: 一年级 20 题
  python main.py -g 3 -n 30               # 三年级 30 题
  python main.py -g 5 -n 50 -o ./output   # 五年级 50 题，输出到 ./output
  python main.py -g 2 -n 40 --seed 42     # 固定随机种子，可复现
  python main.py --list-grades            # 查看所有年级配置
        """,
    )

    parser.add_argument(
        "-g", "--grade", type=int, default=1,
        help="年级 (1-6)，默认 1"
    )
    parser.add_argument(
        "-n", "--num", type=int, default=20,
        help="题目数量，默认 20"
    )
    parser.add_argument(
        "-o", "--output", type=str, default=None,
        help="输出目录，默认在桌面创建 primary-math-output 文件夹"
    )
    parser.add_argument(
        "--seed", type=int, default=None,
        help="随机种子，用于复现相同题目"
    )
    parser.add_argument(
        "--list-grades", action="store_true",
        help="列出所有预设年级配置并退出"
    )
    parser.add_argument(
        "--no-verify", action="store_true",
        help="跳过答案校验"
    )

    args = parser.parse_args()

    # ---- 列出年级配置 ----
    if args.list_grades:
        print("=" * 70)
        print("  各年级预设配置一览")
        print("=" * 70)
        for g, cfg in sorted(PRESET_GRADES.items()):
            print(f"\n  [{g}] {cfg.grade_name}")
            print(f"      数值范围: {cfg.min_num} ~ {cfg.max_num}")
            types = []
            if cfg.enable_addition:
                types.append("加法")
            if cfg.enable_subtraction:
                types.append("减法")
            if cfg.enable_multiplication:
                types.append("乘法")
            if cfg.enable_division:
                types.append("除法")
            if cfg.enable_mixed:
                types.append("四则混合")
            if cfg.enable_word_problems:
                types.append("应用题")
            print(f"      启用题型: {', '.join(types) if types else '无'}")
            if cfg.decimal_places > 0:
                print(f"      小数位数: {cfg.decimal_places}")
            if cfg.allow_carry:
                print(f"      允许进位加法: 是")
            if cfg.allow_borrow:
                print(f"      允许退位减法: 是")
        print()
        return

    # ---- 参数校验 ----
    if args.grade not in range(1, 7):
        print(f"[错误] 年级参数无效: {args.grade}，支持 1-6")
        sys.exit(1)
    if args.num < 1 or args.num > 500:
        print(f"[错误] 题目数量无效: {args.num}，建议 1-500")
        sys.exit(1)

    # ---- 输出目录 ----
    if args.output:
        output_dir = os.path.abspath(args.output)
    else:
        output_dir = os.path.join(os.path.expanduser("~"), "Desktop", "primary-math-output")
    os.makedirs(output_dir, exist_ok=True)

    # ---- 生成题目 ----
    print(f"\n{'=' * 50}")
    print(f"  小学生数学练习题目自动生成系统")
    print(f"{'=' * 50}")
    print(f"  年级: {args.grade}")
    print(f"  数量: {args.num} 道")
    print(f"  输出: {output_dir}")
    print(f"{'=' * 50}\n")

    cfg = get_grade_config(args.grade)
    gen = ExerciseGenerator(cfg, seed=args.seed)
    questions = gen.generate(args.num)

    # ---- 校验答案 ----
    if not args.no_verify:
        report = verify_answers(questions)
        print(f"  答案校验: {report['correct']}/{report['total']} 正确")
        if report["errors"]:
            print(f"  注意: 有 {len(report['errors'])} 道题校验不通过")
        batch_calc(questions)

    # ---- 导出 ----
    print("  正在导出...")
    grade_name = cfg.grade_name

    files = export_all(
        questions=questions,
        grade_name=grade_name,
        output_dir=output_dir,
        prefix=f"{grade_name}_练习",
    )

    # ---- 结果汇总 ----
    print(f"\n{'=' * 50}")
    print(f"  生成完毕！")
    print(f"{'=' * 50}")
    print(f"  题目文件: {files['txt_questions']}")
    print(f"  答案文件: {files['txt_answers']}")
    print(f"  Word试卷: {files['docx']}")
    print(f"{'=' * 50}\n")

    # 输出题目预览（前 5 道）
    print("【题目预览】")
    for q in questions[:5]:
        print(f"  {q['question_line']}")
    if len(questions) > 5:
        print(f"  ... 共 {len(questions)} 道")
    print()


if __name__ == "__main__":
    main()
