# -*- coding: utf-8 -*-
"""
小学生数学练习题目自动生成系统 —— 难度参数配置模块
======================================================
支持 1-6 年级，可灵活配置题型、数值范围、运算规则等参数。
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class GradeConfig:
    """单个年级的难度配置"""

    # ---- 基础信息 ----
    grade: int = 1                                          # 年级 (1-6)
    grade_name: str = "一年级"                               # 年级名称

    # ---- 数值范围 ----
    min_num: int = 0                                        # 最小数值
    max_num: int = 20                                       # 最大数值
    decimal_places: int = 0                                 # 小数位数（0 表示整数）

    # ---- 题型开关 ----
    enable_addition: bool = True                            # 加法
    enable_subtraction: bool = True                         # 减法
    enable_multiplication: bool = False                     # 乘法
    enable_division: bool = False                           # 除法
    enable_mixed: bool = False                              # 四则混合运算
    enable_word_problems: bool = False                      # 简单应用题

    # ---- 运算特性 ----
    allow_carry: bool = False                               # 允许进位加法
    allow_borrow: bool = False                              # 允许退位减法
    allow_remainder: bool = False                           # 允许带余数除法
    allow_parentheses: bool = False                         # 混合运算中允许括号
    mixed_operators_count: int = 2                          # 混合运算中运算符个数

    # ---- 乘除法范围 ----
    multiplication_table_max: int = 9                       # 乘法口诀表上限（如 9 即 1~9 的乘法）
    division_divisor_max: int = 9                           # 除法除数上限

    # ---- 应用题 ----
    word_problem_templates: List[str] = field(default_factory=lambda: [
        "小明有{a}个苹果，吃了{b}个，还剩几个？",
        "树上有{a}只鸟，飞来了{b}只，现在有几只？",
    ])

    def __post_init__(self):
        """初始化后自动校验"""
        if self.enable_mixed:
            # 混合运算至少需要加法和减法
            if not (self.enable_addition or self.enable_subtraction or
                    self.enable_multiplication or self.enable_division):
                raise ValueError(f"年级{self.grade}: 启用混合运算但未启用任何基础运算")
        if self.enable_division and self.division_divisor_max < 2:
            raise ValueError(f"年级{self.grade}: 除数上限不能小于2")


# ============================================================
# 预设各年级配置（可根据需要修改）
# ============================================================

PRESET_GRADES = {
    1: GradeConfig(
        grade=1, grade_name="一年级",
        min_num=0, max_num=20,
        enable_addition=True, enable_subtraction=True,
        enable_multiplication=False, enable_division=False,
        enable_mixed=False, enable_word_problems=False,
        allow_carry=False, allow_borrow=False,
        word_problem_templates=[
            "小明有{a}个苹果，吃了{b}个，还剩几个？",
            "树上有{a}只鸟，飞来了{b}只，现在有几只？",
        ],
    ),
    2: GradeConfig(
        grade=2, grade_name="二年级",
        min_num=0, max_num=100,
        enable_addition=True, enable_subtraction=True,
        enable_multiplication=True, enable_division=False,
        enable_mixed=False, enable_word_problems=False,
        allow_carry=True, allow_borrow=True,
        multiplication_table_max=9,
        word_problem_templates=[
            "小明有{a}颗糖，给了小红{b}颗，还剩几颗？",
        ],
    ),
    3: GradeConfig(
        grade=3, grade_name="三年级",
        min_num=0, max_num=1000,
        enable_addition=True, enable_subtraction=True,
        enable_multiplication=True, enable_division=True,
        enable_mixed=True, enable_word_problems=False,
        allow_carry=True, allow_borrow=True,
        allow_remainder=False,
        multiplication_table_max=9, division_divisor_max=9,
        mixed_operators_count=2, allow_parentheses=False,
    ),
    4: GradeConfig(
        grade=4, grade_name="四年级",
        min_num=0, max_num=10000,
        enable_addition=True, enable_subtraction=True,
        enable_multiplication=True, enable_division=True,
        enable_mixed=True, enable_word_problems=False,
        allow_carry=True, allow_borrow=True,
        allow_remainder=True,
        multiplication_table_max=12, division_divisor_max=12,
        mixed_operators_count=3, allow_parentheses=True,
        decimal_places=0,
    ),
    5: GradeConfig(
        grade=5, grade_name="五年级",
        min_num=0, max_num=100000,
        enable_addition=True, enable_subtraction=True,
        enable_multiplication=True, enable_division=True,
        enable_mixed=True, enable_word_problems=True,
        allow_carry=True, allow_borrow=True,
        allow_remainder=True,
        multiplication_table_max=12, division_divisor_max=20,
        mixed_operators_count=3, allow_parentheses=True,
        decimal_places=1,       # 一位小数
    ),
    6: GradeConfig(
        grade=6, grade_name="六年级",
        min_num=0, max_num=1000000,
        enable_addition=True, enable_subtraction=True,
        enable_multiplication=True, enable_division=True,
        enable_mixed=True, enable_word_problems=True,
        allow_carry=True, allow_borrow=True,
        allow_remainder=True,
        multiplication_table_max=15, division_divisor_max=50,
        mixed_operators_count=4, allow_parentheses=True,
        decimal_places=2,       # 两位小数
    ),
}


def get_grade_config(grade: int) -> GradeConfig:
    """
    获取指定年级的预设配置。

    Args:
        grade: 年级编号 (1-6)

    Returns:
        GradeConfig 对象

    Raises:
        ValueError: 年级超出范围
    """
    if grade not in PRESET_GRADES:
        raise ValueError(f"无效年级: {grade}，支持 1-6 年级")
    return PRESET_GRADES[grade]


def create_custom_config(**kwargs) -> GradeConfig:
    """
    创建自定义难度配置（可覆盖任意参数）。

    Args:
        **kwargs: GradeConfig 中的任意字段

    Returns:
        自定义 GradeConfig 对象

    Example:
        >>> cfg = create_custom_config(grade=3, max_num=500, enable_mixed=False)
    """
    invalid_keys = [k for k in kwargs if k not in GradeConfig.__dataclass_fields__]
    if invalid_keys:
        raise ValueError(f"无效参数: {invalid_keys}")
    return GradeConfig(**kwargs)
