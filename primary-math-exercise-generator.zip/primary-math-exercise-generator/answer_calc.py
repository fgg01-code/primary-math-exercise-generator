# -*- coding: utf-8 -*-
"""
小学生数学练习题目自动生成系统 —— 答案计算模块
================================================
提供通用的表达式求值和结果校验能力，可独立使用或配合生成器使用。
"""

import re
from typing import List, Dict, Any


def calc_answer(question: dict) -> str:
    """
    计算单道题的标准答案。

    支持 generator.py 输出的所有题型，包括纯加减法、乘除法、
    四则混合运算（含括号）及简单应用题。

    Args:
        question: 题目 dict，必须包含 "expression" 字段

    Returns:
        标准答案字符串

    Raises:
        ValueError: 无法解析表达式
    """
    expr = question.get("expression", question.get("topic", ""))

    # 应用题：从模板中提取数值并计算
    if question.get("type", "").endswith("应用题"):
        return _calc_word_problem(question)

    # 带余数除法
    if question.get("type") == "除法" and "余" in question.get("answer", ""):
        return _calc_division_with_remainder(expr)

    # 普通表达式求值
    return _eval_expression(expr)


def _calc_word_problem(question: dict) -> str:
    """计算应用题的答案"""
    topic = question.get("topic", "")
    nums = re.findall(r'\d+', topic)
    if len(nums) < 2:
        return "无法计算"

    a, b = int(nums[0]), int(nums[1])

    if any(kw in topic for kw in ["吃了", "飞走", "给了", "拿走", "卖掉"]):
        result = a - b
    elif any(kw in topic for kw in ["飞来", "又来", "买来", "加入"]):
        result = a + b
    elif any(kw in topic for kw in ["每人", "每组", "每排"]):
        result = a * b
    elif any(kw in topic for kw in ["平均"]):
        result = a // b
    else:
        result = a + b  # 默认加法

    return str(result)


def _calc_division_with_remainder(expr: str) -> str:
    """计算带余数除法"""
    # expr 格式如: "30 // 7 (商4, 余2)"
    match = re.search(r'(\d+)\s*//\s*(\d+)', expr)
    if not match:
        return "无法计算"
    dividend = int(match.group(1))
    divisor = int(match.group(2))
    if divisor == 0:
        return "除数不能为0"
    quotient = dividend // divisor
    remainder = dividend % divisor
    if remainder == 0:
        return str(quotient)
    return f"{quotient} 余 {remainder}"


def _eval_expression(expr: str) -> str:
    """
    安全求值数学表达式。

    将中文运算符转换为 Python 运算符后计算，并过滤非法字符。

    Args:
        expr: 数学表达式字符串

    Returns:
        计算结果字符串

    Raises:
        ValueError: 表达式含非法字符或计算错误
    """
    # 标准化运算符
    expr = expr.replace("×", "*").replace("÷", "/").replace(" ", "")

    # 安全检查：只允许数字、运算符、括号、空格、小数点
    allowed = re.compile(r'^[\d+\-*/().\s]+$')
    if not allowed.match(expr):
        raise ValueError(f"表达式包含非法字符: {expr}")

    try:
        result = eval(expr)
    except ZeroDivisionError:
        return "除数不能为0"
    except Exception as e:
        raise ValueError(f"表达式计算失败: {expr}, 错误: {e}")

    # 格式化结果
    if isinstance(result, float) and result == int(result):
        return str(int(result))
    elif isinstance(result, float):
        # 最多保留 4 位小数，去除尾部多余的 0
        formatted = f"{result:.4f}".rstrip('0').rstrip('.')
        return formatted
    return str(result)


def batch_calc(questions: List[dict]) -> List[dict]:
    """
    批量为题目计算答案，直接更新 questions 中的 answer 字段。

    Args:
        questions: 题目列表

    Returns:
        更新后的题目列表（原地修改）
    """
    for q in questions:
        if not q.get("answer"):
            q["answer"] = calc_answer(q)
        else:
            # 已有生成器给出的答案，用独立计算进行校验
            try:
                recalc = calc_answer(q)
                if recalc != q["answer"] and recalc != "无法计算":
                    # 以重新计算的结果为准
                    q["answer"] = recalc
            except ValueError:
                pass  # 如果重新计算失败，保留原有答案
    return questions


def verify_answers(questions: List[dict]) -> Dict[str, Any]:
    """
    校验所有题目答案是否正确。

    Args:
        questions: 题目列表

    Returns:
        校验报告: {"total": int, "correct": int, "errors": list}
    """
    total = len(questions)
    correct = 0
    errors = []

    for q in questions:
        try:
            recalc = calc_answer(q)
            if recalc != "无法计算" and recalc == q.get("answer", ""):
                correct += 1
            else:
                errors.append({
                    "id": q["id"],
                    "topic": q["topic"],
                    "expected": q.get("answer", ""),
                    "recalculated": recalc,
                })
        except Exception as e:
            errors.append({
                "id": q["id"],
                "topic": q["topic"],
                "error": str(e),
            })

    return {
        "total": total,
        "correct": correct,
        "errors": errors,
    }
